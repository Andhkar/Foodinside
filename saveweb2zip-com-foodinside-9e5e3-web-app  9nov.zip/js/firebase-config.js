/* ==========================================================================
   FoodInside — Central Firebase Configuration & Services Initializer
   Project: foodinside-9e5e3 (Sarangarh Cloud Kitchen)
   ========================================================================== */

const FOODINSIDE_FIREBASE_CONFIG = {
  apiKey: "AIzaSyA07hX4J5F5QeNKvn_OKTJE-Bu-8Z7CKs0",
  authDomain: "foodinside-9e5e3.firebaseapp.com",
  projectId: "foodinside-9e5e3",
  storageBucket: "foodinside-9e5e3.firebasestorage.app",
  messagingSenderId: "1035116821708",
  appId: "1:1035116821708:web:87f7de3631d07ab4e9d669",
  measurementId: "G-5CWHSBR6GT"
};

// Initialize Firebase App safely if Firebase SDK is present
if (typeof firebase !== 'undefined') {
  if (!firebase.apps || !firebase.apps.length) {
    try {
      firebase.initializeApp(FOODINSIDE_FIREBASE_CONFIG);
      console.log("✅ FoodInside Firebase App initialized successfully.");
    } catch (e) {
      console.warn("Firebase initialization warning:", e);
    }
  }
}

// Global helpers for FoodInside session management
window.FoodInsideAuth = {
  config: FOODINSIDE_FIREBASE_CONFIG,
  
  // Get current customer from localStorage or Firebase
  getCustomer: function() {
    try {
      return JSON.parse(localStorage.getItem('foodinsideCustomer') || 'null');
    } catch (e) {
      return null;
    }
  },

  // Save customer session
  setCustomer: function(customerData) {
    localStorage.setItem('foodinsideCustomer', JSON.stringify(customerData));
    // Trigger cross-component sync
    window.dispatchEvent(new CustomEvent('foodinside:auth-changed', { detail: customerData }));
  },

  // Clear customer session
  clearCustomer: function() {
    localStorage.removeItem('foodinsideCustomer');
    if (typeof firebase !== 'undefined' && firebase.auth) {
      firebase.auth().signOut().catch(() => {});
    }
    window.dispatchEvent(new CustomEvent('foodinside:auth-changed', { detail: null }));
  }
};
