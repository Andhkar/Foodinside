/* ==========================================================================
   FoodInside — Application Logic & Google Maps Integration
   ========================================================================== */

// --- GOOGLE MAPS CONFIGURATION ---
const GOOGLE_MAPS_CONFIG = {
  // If you obtain a Google Maps JavaScript API key from Google Cloud Console,
  // paste it below to enable advanced interactive Maps JavaScript SDK features.
  // Leave blank to use instant Google Maps Embed + Geolocation (no API key required).
  apiKey: "",

  // FoodInside Kitchen Physical Coordinates (Sarangarh, CG)
  kitchen: {
    name: "FoodInside Cloud Kitchen",
    address: "Bilaspur Road, Pushpwatika ke bagal, Sarangarh, Chhattisgarh 496445",
    lat: 21.5911,
    lng: 83.0769
  }
};

// --- MENU DATA ---
const foods = [
  { id: 1, name: "Vada Pav", category: "Snacks", price: 30, emoji: "🍔", desc: "Authentic Mumbai-style spicy potato vada in fresh pav" },
  { id: 2, name: "Samosa (2 pcs)", category: "Snacks", price: 20, emoji: "🥟", desc: "Crispy hot samosas stuffed with spiced potatoes" },
  { id: 3, name: "Pakodi Plate", category: "Snacks", price: 20, emoji: "🍘", desc: "Freshly fried crispy mixed vegetable pakodis" },
  { id: 4, name: "Masala Fries", category: "Snacks", price: 60, emoji: "🍟", desc: "Crisp golden fries tossed in chatpata masala" },
  { id: 5, name: "Samosa Chaat", category: "Chaat", price: 50, emoji: "🥗", desc: "Crushed hot samosa topped with chhole, curd & chutneys" },
  { id: 6, name: "Papdi Chaat", category: "Chaat", price: 50, emoji: "🧆", desc: "Crispy papdis layered with dahi, sev & tangy tamarind" },
  { id: 7, name: "Veg Burger", category: "Meals", price: 70, emoji: "🍔", desc: "Crispy herb patty with fresh lettuce, mayo & tomatoes" },
  { id: 8, name: "Paneer Burger", category: "Meals", price: 95, emoji: "🥪", desc: "Loaded grilled paneer patty with spicy tandoori spread" },
  { id: 9, name: "Margherita Pizza", category: "Pizza", price: 149, emoji: "🍕", desc: "Classic 7-inch cheese pizza with herb tomato sauce" },
  { id: 10, name: "Farmhouse Pizza", category: "Pizza", price: 189, emoji: "🍕", desc: "Topped with crunchy onions, capsicum, corn & mozzarella" },
  { id: 11, name: "Cold Drink (300ml)", category: "Drinks", price: 30, emoji: "🥤", desc: "Chilled refreshing soda (Thums Up / Sprite)" },
  { id: 12, name: "Thick Cold Coffee", category: "Drinks", price: 60, emoji: "☕", desc: "Creamy blended cold coffee with chocolate drizzle" }
];

// --- APP STATE ---
let cart = JSON.parse(localStorage.getItem("foodinsideCart") || "[]");
let userLocation = JSON.parse(localStorage.getItem("foodinsideUserGps") || "null");
let activeCategory = "All";
let searchQuery = "";

// --- DOM ELEMENTS ---
const menuEl = document.getElementById("menu");
const emptyEl = document.getElementById("empty");
const searchInput = document.getElementById("search");
const cartBtn = document.getElementById("cartBtn");
const cartCount = document.getElementById("cartCount");
const toastEl = document.getElementById("toast");

// Hero Location Elements
const deliveryAddressInput = document.getElementById("deliveryAddressInput");
const btnDetectGps = document.getElementById("btnDetectGps");
const gpsStatusContainer = document.getElementById("gpsStatusContainer");
const gpsStatusText = document.getElementById("gpsStatusText");
const viewGpsMapLink = document.getElementById("viewGpsMapLink");

// Cart Modal Elements
const cartModal = document.getElementById("cartModal");
const closeCartBtn = document.getElementById("closeCartBtn");
const cartList = document.getElementById("cartList");
const subtotalAmount = document.getElementById("subtotalAmount");
const totalAmount = document.getElementById("totalAmount");
const btnPayAmount = document.getElementById("btnPayAmount");
const modalDetectGps = document.getElementById("modalDetectGps");
const modalGpsStatus = document.getElementById("modalGpsStatus");
const modalGpsText = document.getElementById("modalGpsText");
const modalGpsLink = document.getElementById("modalGpsLink");
const modalMapIframe = document.getElementById("modalMapIframe");
const placeOrderBtn = document.getElementById("placeOrderBtn");

// Orders Modal Elements
const ordersBtn = document.getElementById("ordersBtn");
const ordersCount = document.getElementById("ordersCount");
const ordersModal = document.getElementById("ordersModal");
const closeOrdersBtn = document.getElementById("closeOrdersBtn");
const ordersList = document.getElementById("ordersList");

// Success Modal Elements
const successModal = document.getElementById("successModal");
const closeSuccessBtn = document.getElementById("closeSuccessBtn");
const successOrderId = document.getElementById("successOrderId");
const successOrderTotal = document.getElementById("successOrderTotal");
const successAddress = document.getElementById("successAddress");
const successMapBtnWrap = document.getElementById("successMapBtnWrap");
const successMapBtn = document.getElementById("successMapBtn");

// --- INITIALIZATION ---
function init() {
  syncAuthSession();
  renderMenu();
  updateCartBadge();
  updateOrdersCount();
  setupEventListeners();

  // If previous GPS location exists in session, restore UI
  if (userLocation) {
    applyLocationToUI(userLocation);
  }

  // Load Google Maps SDK if API key configured
  if (GOOGLE_MAPS_CONFIG.apiKey) {
    loadGoogleMapsSdk();
  }

  // Auto-open orders modal if requested by login profile redirect or hash
  if (localStorage.getItem("openOrdersOnLoad") === "true" || window.location.hash === "#orders") {
    localStorage.removeItem("openOrdersOnLoad");
    setTimeout(openOrdersModal, 400);
  }
}

// --- SYNC AUTH SESSION WITH FIREBASE & LOCAL STORAGE ---
function syncAuthSession() {
  const authNavText = document.getElementById("authNavText");
  const authNavBtn = document.getElementById("authNavBtn");
  
  function updateAuthUI(customer) {
    if (authNavText && authNavBtn) {
      if (customer && customer.phone) {
        const shortPhone = customer.phone.slice(-10);
        authNavText.textContent = customer.name && customer.name !== "Foodie" ? customer.name : `+91 ${shortPhone.slice(0,5)}...`;
        authNavBtn.title = `Logged in as ${customer.phone}. Click to view account.`;
        authNavBtn.style.borderColor = "var(--primary)";
      } else {
        authNavText.textContent = "Login";
        authNavBtn.title = "Customer Login";
        authNavBtn.style.borderColor = "";
      }
    }
  }

  const currentCustomer = window.FoodInsideAuth ? window.FoodInsideAuth.getCustomer() : null;
  updateAuthUI(currentCustomer);

  // Listen for custom auth events
  window.addEventListener('foodinside:auth-changed', (e) => {
    updateAuthUI(e.detail);
  });

  // Listen for Firebase native auth state
  if (typeof firebase !== 'undefined' && firebase.auth) {
    firebase.auth().onAuthStateChanged(user => {
      if (user && user.phoneNumber) {
        const customer = window.FoodInsideAuth.getCustomer() || {};
        customer.phone = user.phoneNumber;
        customer.uid = user.uid;
        window.FoodInsideAuth.setCustomer(customer);
        updateAuthUI(customer);
      }
    });
  }
}

// --- RENDER MENU ---
function renderMenu() {
  const menuStock = JSON.parse(localStorage.getItem("foodinsideMenuStock") || "{}");

  const filtered = foods.filter(item => {
    const matchesCat = activeCategory === "All" || item.category === activeCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.desc.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  if (filtered.length === 0) {
    menuEl.innerHTML = "";
    emptyEl.hidden = false;
    return;
  }

  emptyEl.hidden = true;
  menuEl.innerHTML = filtered.map(item => {
    const isOutOfStock = menuStock[item.id] === false;
    return `
      <article class="card ${isOutOfStock ? 'out-of-stock-card' : ''}">
        <div class="food-img">${item.emoji}</div>
        <div class="info">
          <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <h3>${item.name}</h3>
            ${isOutOfStock ? `<span style="font-size:11px; background:#fee2e2; color:#dc2626; font-weight:700; padding:2px 8px; border-radius:999px;">Sold Out</span>` : ''}
          </div>
          <p>${item.desc}</p>
          <div class="row">
            <span class="price">₹${item.price}</span>
            ${isOutOfStock ? `
              <button class="add" disabled style="opacity:0.4; cursor:not-allowed; background:#9ca3af;">Sold Out</button>
            ` : `
              <button class="add" onclick="addToCart(${item.id})">Add +</button>
            `}
          </div>
        </div>
      </article>
    `;
  }).join("");
}

// --- CART LOGIC ---
function addToCart(foodId) {
  const food = foods.find(f => f.id === foodId);
  if (!food) return;

  const existing = cart.find(c => c.id === foodId);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ id: food.id, name: food.name, price: food.price, qty: 1, emoji: food.emoji });
  }

  saveCart();
  updateCartBadge();
  showToast(`Added ${food.name} to cart`);
}

function updateQty(foodId, delta) {
  const item = cart.find(c => c.id === foodId);
  if (!item) return;

  item.qty += delta;
  if (item.qty <= 0) {
    cart = cart.filter(c => c.id !== foodId);
  }

  saveCart();
  updateCartBadge();
  renderCartModal();
}

function saveCart() {
  localStorage.setItem("foodinsideCart", JSON.stringify(cart));
}

function updateCartBadge() {
  const totalCount = cart.reduce((sum, item) => sum + item.qty, 0);
  cartCount.textContent = totalCount;
}

// --- GOOGLE MAPS GPS CAPTURE ---
function detectUserLocation(source = "hero") {
  if (!navigator.geolocation) {
    alert("Geolocation is not supported by your browser. Please enter your address manually.");
    return;
  }

  const btn = source === "modal" ? modalDetectGps : btnDetectGps;
  const originalText = btn.innerHTML;
  btn.innerHTML = `<span>⏳</span> Detecting Google Maps Pin...`;
  btn.disabled = true;

  navigator.geolocation.getCurrentPosition(
    position => {
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;
      const accuracy = position.coords.accuracy;

      userLocation = {
        latitude: lat,
        longitude: lng,
        accuracy: Math.round(accuracy),
        mapUrl: `https://www.google.com/maps?q=${lat},${lng}`,
        routeUrl: `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(GOOGLE_MAPS_CONFIG.kitchen.address)}&destination=${lat},${lng}`,
        embedUrl: `https://maps.google.com/maps?q=${lat},${lng}&z=16&output=embed`
      };

      localStorage.setItem("foodinsideUserGps", JSON.stringify(userLocation));
      applyLocationToUI(userLocation);

      btn.innerHTML = originalText;
      btn.disabled = false;
      showToast("📍 Location pin captured on Google Maps!");
    },
    error => {
      console.warn("Geolocation error:", error);
      btn.innerHTML = originalText;
      btn.disabled = false;
      let msg = "Could not detect location. Please check browser permissions.";
      if (error.code === 1) msg = "Location permission denied. Please allow location access in your browser.";
      alert(msg);
    },
    { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
  );
}

function applyLocationToUI(loc) {
  if (!loc) return;

  const coordStr = `${loc.latitude.toFixed(5)}, ${loc.longitude.toFixed(5)}`;

  // Hero section updates
  if (deliveryAddressInput && !deliveryAddressInput.value) {
    deliveryAddressInput.value = `📍 GPS Pin: ${coordStr} (Sarangarh)`;
  }
  if (gpsStatusContainer && gpsStatusText && viewGpsMapLink) {
    gpsStatusContainer.style.display = "block";
    gpsStatusText.textContent = `GPS Pin: ${coordStr} (±${loc.accuracy}m)`;
    viewGpsMapLink.href = loc.mapUrl;
  }

  // Modal checkout updates
  const orderAddressEl = document.getElementById("orderAddress");
  if (orderAddressEl && !orderAddressEl.value) {
    orderAddressEl.value = `📍 GPS Pin: ${coordStr} (Sarangarh)`;
  }
  if (modalGpsStatus && modalGpsText && modalGpsLink && modalMapIframe) {
    modalGpsStatus.style.display = "block";
    modalGpsText.textContent = `📍 Delivery Pin: ${coordStr} (Accuracy: ±${loc.accuracy}m)`;
    modalGpsLink.href = loc.mapUrl;
    modalMapIframe.src = loc.embedUrl;
  }
}

// --- CART & CHECKOUT MODAL ---
function openCartModal() {
  if (cart.length === 0) {
    showToast("Your cart is empty. Add food items first!");
    return;
  }

  renderCartModal();
  cartModal.classList.add("open");
}

function renderCartModal() {
  if (cart.length === 0) {
    cartModal.classList.remove("open");
    return;
  }

  cartList.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div>
        <div class="cart-item-title">${item.emoji} ${item.name}</div>
        <div class="cart-item-price">₹${item.price} each</div>
      </div>
      <div class="qty-controls">
        <button class="qty-btn" onclick="updateQty(${item.id}, -1)">-</button>
        <span class="qty-val">${item.qty}</span>
        <button class="qty-btn" onclick="updateQty(${item.id}, 1)">+</button>
      </div>
    </div>
  `).join("");

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const delivery = 30;
  const total = subtotal + delivery;

  subtotalAmount.textContent = subtotal;
  totalAmount.textContent = total;
  btnPayAmount.textContent = total;

  // Check auth and auto-fill customer details
  const customer = window.FoodInsideAuth ? window.FoodInsideAuth.getCustomer() : null;
  const cartAuthGuest = document.getElementById("cartAuthGuest");
  const cartAuthUser = document.getElementById("cartAuthUser");
  const cartAuthPhone = document.getElementById("cartAuthPhone");
  const orderNameEl = document.getElementById("orderName");
  const orderPhoneEl = document.getElementById("orderPhone");
  const orderAddressEl = document.getElementById("orderAddress");

  if (customer && customer.phone) {
    if (cartAuthGuest) cartAuthGuest.style.display = "none";
    if (cartAuthUser) {
      cartAuthUser.style.display = "block";
      if (cartAuthPhone) cartAuthPhone.textContent = customer.phone;
    }
    if (orderNameEl && !orderNameEl.value && customer.name && customer.name !== "Foodie") {
      orderNameEl.value = customer.name;
    }
    if (orderPhoneEl && !orderPhoneEl.value) {
      orderPhoneEl.value = customer.phone.replace(/\D/g, "").slice(-10);
    }
    if (orderAddressEl && !orderAddressEl.value && customer.address) {
      orderAddressEl.value = customer.address;
    }
  } else {
    if (cartAuthGuest) cartAuthGuest.style.display = "block";
    if (cartAuthUser) cartAuthUser.style.display = "none";
  }

  // Auto-fill address if user typed in hero
  if (deliveryAddressInput && deliveryAddressInput.value && orderAddressEl && !orderAddressEl.value) {
    orderAddressEl.value = deliveryAddressInput.value;
  }

  // Apply location preview in modal if already captured
  if (userLocation) {
    applyLocationToUI(userLocation);
  }
}

// --- PLACE ORDER ---
function placeOrder() {
  // Check if kitchen paused
  const kitchenStatus = localStorage.getItem("foodinsideKitchenStatus") || "open";
  if (kitchenStatus === "paused") {
    alert("⚠️ FoodInside Kitchen is temporarily paused by the kitchen admin and is not accepting orders at this moment. Please try again shortly!");
    return;
  }

  const name = document.getElementById("orderName").value.trim();
  const phone = document.getElementById("orderPhone").value.trim();
  const address = document.getElementById("orderAddress").value.trim();
  const payment = document.getElementById("orderPayment").value;

  if (cart.length === 0) {
    alert("Cart is empty!");
    return;
  }
  if (!name) {
    alert("Please enter your name.");
    return;
  }
  if (!phone || phone.length < 10) {
    alert("Please enter a valid 10-digit phone number.");
    return;
  }
  if (!address) {
    alert("Please enter your delivery address or click 'Auto-Capture My GPS Pin'.");
    return;
  }

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const deliveryFee = 30;
  const total = subtotal + deliveryFee;
  const orderId = "FI-" + Date.now().toString().slice(-6);

  const customer = window.FoodInsideAuth ? window.FoodInsideAuth.getCustomer() : null;

  const order = {
    id: orderId,
    customer: { 
      name, 
      phone, 
      address,
      uid: customer ? customer.uid : null,
      isVerifiedPhone: !!(customer && customer.phone)
    },
    items: [...cart],
    subtotal,
    deliveryFee,
    total,
    paymentMethod: payment,
    location: userLocation,
    status: "Order Received",
    createdAt: new Date().toLocaleString()
  };

  // If customer is logged in, update their name and address profile
  if (customer && window.FoodInsideAuth) {
    customer.name = name;
    if (!customer.address) customer.address = address;
    window.FoodInsideAuth.setCustomer(customer);
  }

  // Save order to LocalStorage
  const orders = JSON.parse(localStorage.getItem("foodinsideOrders") || "[]");
  orders.push(order);
  localStorage.setItem("foodinsideOrders", JSON.stringify(orders));

  // Reset cart
  cart = [];
  saveCart();
  updateCartBadge();
  updateOrdersCount();

  // Close cart modal
  cartModal.classList.remove("open");

  // Show Success Modal
  successOrderId.textContent = "#" + orderId;
  successOrderTotal.textContent = total;
  successAddress.textContent = address;

  if (order.location) {
    successMapBtnWrap.style.display = "block";
    successMapBtn.href = order.location.routeUrl;
  } else {
    successMapBtnWrap.style.display = "none";
  }

  successModal.classList.add("open");
}

// --- ORDERS / ADMIN MODAL ---
function openOrdersModal() {
  renderOrdersModal();
  ordersModal.classList.add("open");
}

function updateOrdersCount() {
  const orders = JSON.parse(localStorage.getItem("foodinsideOrders") || "[]");
  ordersCount.textContent = orders.length;
}

function renderOrdersModal() {
  const orders = JSON.parse(localStorage.getItem("foodinsideOrders") || "[]");

  if (orders.length === 0) {
    ordersList.innerHTML = `<p style="text-align:center; padding:24px; color:var(--text-muted)">No orders placed yet. Place an order to see live Google Maps tracking here!</p>`;
    return;
  }

  ordersList.innerHTML = orders.slice().reverse().map(order => `
    <div class="order-card">
      <div class="order-header">
        <span class="order-id">#${order.id}</span>
        <span class="order-status">${order.status}</span>
      </div>
      <p style="font-size: 13px; margin-bottom: 4px;">
        <strong>Customer:</strong> ${order.customer.name} (${order.customer.phone})
      </p>
      <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 4px;">
        <strong>Address:</strong> ${order.customer.address}
      </p>
      <p style="font-size: 13px; margin-bottom: 6px;">
        <strong>Items:</strong> ${order.items.map(i => `${i.name} × ${i.qty}`).join(", ")}
      </p>
      <p style="font-size: 13px; font-weight: 700; color: var(--primary);">
        Total: ₹${order.total} • ${order.paymentMethod}
      </p>

      <!-- Google Maps Navigation Buttons for Delivery -->
      <div style="margin-top: 10px; display: flex; gap: 8px; flex-wrap: wrap;">
        ${order.location ? `
          <a href="${order.location.mapUrl}" target="_blank" class="order-map-btn">
            📍 Open Location in Google Maps
          </a>
          <a href="${order.location.routeUrl}" target="_blank" class="order-map-btn" style="background:var(--primary); color:#fff; border-color:var(--primary);">
            🧭 Start Delivery Navigation
          </a>
        ` : `
          <a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.customer.address + ' Sarangarh')}" target="_blank" class="order-map-btn">
            🔍 Search Address on Google Maps
          </a>
        `}
      </div>
    </div>
  `).join("");
}

// --- TOAST NOTIFICATIONS ---
function showToast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add("show");
  setTimeout(() => toastEl.classList.remove("show"), 2000);
}

// --- OPTIONAL GOOGLE MAPS JAVASCRIPT SDK LOADER ---
function loadGoogleMapsSdk() {
  if (window.google && window.google.maps) return;
  const script = document.createElement("script");
  script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_CONFIG.apiKey}&libraries=places&callback=initGoogleMapsCallback`;
  script.async = true;
  script.defer = true;
  document.head.appendChild(script);
}

window.initGoogleMapsCallback = function() {
  console.log("Google Maps JavaScript SDK loaded successfully.");
};

// --- EVENT LISTENERS ---
function setupEventListeners() {
  // Search
  searchInput.addEventListener("input", e => {
    searchQuery = e.target.value;
    renderMenu();
  });

  // Category chips
  document.querySelectorAll(".cat-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      document.querySelectorAll(".cat-chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      activeCategory = chip.dataset.cat;
      renderMenu();
    });
  });

  // GPS Detect buttons
  btnDetectGps.addEventListener("click", () => detectUserLocation("hero"));
  modalDetectGps.addEventListener("click", () => detectUserLocation("modal"));

  // Cart Modal
  cartBtn.addEventListener("click", openCartModal);
  closeCartBtn.addEventListener("click", () => cartModal.classList.remove("open"));

  // Orders Modal
  ordersBtn.addEventListener("click", openOrdersModal);
  closeOrdersBtn.addEventListener("click", () => ordersModal.classList.remove("open"));

  // Success Modal
  closeSuccessBtn.addEventListener("click", () => successModal.classList.remove("open"));

  // Place Order
  placeOrderBtn.addEventListener("click", placeOrder);

  // Close modals when clicking overlay background
  [cartModal, ordersModal, successModal].forEach(modal => {
    modal.addEventListener("click", e => {
      if (e.target === modal) modal.classList.remove("open");
    });
  });
}

// Start application
init();
